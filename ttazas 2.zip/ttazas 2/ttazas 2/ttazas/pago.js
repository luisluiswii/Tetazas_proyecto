document.addEventListener('DOMContentLoaded', function() {
    // 1. Inicialización de métodos de pago
    initPaymentMethods();
    
    // 2. Mostrar resumen del carrito
    displayCartItems();
    
    // 3. Configurar botones y validación
    initButtonsAndValidation();
});

// Función para manejar los métodos de pago
function initPaymentMethods() {
    const paymentMethods = document.querySelectorAll('.payment-method');
    const paymentDetails = document.querySelectorAll('.payment-details');
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Remover activo de todos los métodos
            paymentMethods.forEach(m => m.classList.remove('active'));
            paymentDetails.forEach(d => d.classList.remove('active'));
            
            // Activar el seleccionado
            this.classList.add('active');
            const methodType = this.getAttribute('data-method');
            document.getElementById(`${methodType}-details`).classList.add('active');
        });
    });
    
    // Activar el primer método por defecto
    if (paymentMethods.length > 0) {
        paymentMethods[0].click();
    }
}

// Función para mostrar los productos del carrito
function displayCartItems() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const orderProducts = document.getElementById('order-products');
    const summaryTotal = document.getElementById('summary-total');
    
    orderProducts.innerHTML = '';
    
    if (cart.length === 0) {
        orderProducts.innerHTML = '<p class="empty-cart">No hay productos en tu carrito</p>';
        summaryTotal.textContent = '0.00€';
        return;
    }
    
    let subtotal = 0;
    
    cart.forEach(item => {
        const productElement = document.createElement('div');
        productElement.className = 'order-item';
        productElement.innerHTML = `
            <div class="item-info">
                <span class="item-name">${item.name}</span>
                <span class="item-quantity">x${item.quantity}</span>
            </div>
            <span class="item-price">${(item.price * item.quantity).toFixed(2)}€</span>
        `;
        orderProducts.appendChild(productElement);
        subtotal += item.price * item.quantity;
    });
    
    // Calcular envío (ejemplo: 3.00€)
    const shipping = 3.00;
    const total = subtotal + shipping;
    
    // Mostrar subtotal, envío y total
    document.getElementById('summary-subtotal').textContent = `${subtotal.toFixed(2)}€`;
    document.getElementById('summary-shipping').textContent = `${shipping.toFixed(2)}€`;
    summaryTotal.textContent = `${total.toFixed(2)}€`;
}

// Función para configurar botones y validación
function initButtonsAndValidation() {
    // Botón de confirmar pedido
    const confirmButton = document.querySelector('.btn-confirm');
    if (confirmButton) {
        confirmButton.addEventListener('click', confirmOrder);
    }
    
    // Botón de volver a la tienda
    const backButton = document.querySelector('.btn-back');
    if (backButton) {
        backButton.addEventListener('click', () => {
            window.location.href = "index.html";
        });
    }
    
    // Botón para volver al inicio desde el modal
    const backToShopBtn = document.querySelector('.btn-back-to-shop');
    if (backToShopBtn) {
        backToShopBtn.addEventListener('click', function() {
            const modal = document.getElementById('confirmation-modal');
            if (modal) {
                modal.style.display = 'none';
            }
            window.location.href = "index.html";
        });
    }
    
    // Generar número de pedido aleatorio
    const orderNumberElement = document.querySelector('.order-number');
    if (orderNumberElement) {
        orderNumberElement.textContent = `TTZ-${Math.floor(Math.random() * 10000)}`;
    }
}

// Función para confirmar el pedido (mejorada para móviles)
function confirmOrder(e) {
    e.preventDefault();
    
    // Validar campos obligatorios
    const requiredFields = ['nombre', 'email', 'direccion'];
    let isValid = true;
    
    requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            if (!field.value.trim()) {
                field.style.borderColor = 'red';
                isValid = false;
                
                // Scroll al primer campo con error en móviles
                if (!isValid && window.innerWidth <= 768) {
                    field.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            } else {
                field.style.borderColor = '';
            }
        }
    });
    
    if (!isValid) {
        showMobileAlert('¡Faltan datos!', 'Por favor completa todos los campos obligatorios marcados en rojo');
        return;
    }
    
    // Validar método de pago seleccionado
    const activeMethod = document.querySelector('.payment-method.active');
    if (!activeMethod) {
        showMobileAlert('Método de pago', 'Por favor selecciona un método de pago');
        return;
    }
    
    const methodType = activeMethod.getAttribute('data-method');
    let paymentValid = true;
    
    if (methodType === 'tarjeta') {
        const cardFields = ['numero-tarjeta', 'fecha-exp', 'cvv', 'nombre-tarjeta'];
        cardFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field && !field.value.trim()) {
                field.style.borderColor = 'red';
                paymentValid = false;
                
                // Scroll al primer campo con error en móviles
                if (!paymentValid && window.innerWidth <= 768) {
                    field.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            } else if (field) {
                field.style.borderColor = '';
            }
        });
        
        // Validación específica para número de tarjeta
        const numTarjeta = document.getElementById('numero-tarjeta');
        if (numTarjeta && numTarjeta.value.replace(/\s/g, '').length !== 16) {
            numTarjeta.style.borderColor = 'red';
            paymentValid = false;
            showMobileAlert('Tarjeta inválida', 'El número de tarjeta debe tener 16 dígitos');
            return;
        }
    } else if (methodType === 'bizum') {
        const bizumField = document.getElementById('telefono-bizum');
        if (bizumField && !bizumField.value.trim()) {
            bizumField.style.borderColor = 'red';
            paymentValid = false;
            
            if (window.innerWidth <= 768) {
                bizumField.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        } else if (bizumField) {
            bizumField.style.borderColor = '';
        }
    }
    
    if (!paymentValid) {
        showMobileAlert('¡Faltan datos!', 'Por favor completa la información de tu método de pago');
        return;
    }
    
    // Mostrar confirmación
    showOrderConfirmation();
}

// Función para mostrar alertas adaptadas a móviles
function showMobileAlert(title, message) {
    if (window.innerWidth <= 768) {
        // Usar alerta nativa en móviles para mejor experiencia
        alert(`${title}\n${message}`);
    } else {
        // Usar SweetAlert o similar en desktop
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                title: title,
                text: message,
                icon: 'warning',
                confirmButtonColor: '#FF5151'
            });
        } else {
            alert(`${title}\n${message}`);
        }
    }
}

// Función para mostrar la confirmación del pedido
function showOrderConfirmation() {
    const name = document.getElementById('nombre').value;
    
    // Versión para móviles
    if (window.innerWidth <= 768) {
        const modal = document.getElementById('confirmation-modal');
        if (modal) {
            modal.style.display = 'block';
            
            // Asegurar que el modal sea visible en móviles
            modal.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            alert(`¡Gracias por tu compra, ${name}! Tu pedido ha sido procesado.`);
            localStorage.removeItem('cart');
            window.location.href = "index.html";
        }
    } 
    // Versión para desktop con SweetAlert
    else if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: '¡Muchas gracias por su compra!',
            html: '<strong>Goku está muy orgulloso de ti</strong> 🐉✨',
            imageUrl: './imagenes/goku.jpg',
            imageWidth: 200,
            imageHeight: 200,
            background: '#1a1a2e',
            color: '#ffffff',
            confirmButtonText: '¡Seguir comprando!',
            confirmButtonColor: '#FF5151',
            customClass: {
                popup: 'otaku-popup',
                title: 'otaku-title',
                htmlContainer: 'otaku-html'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.removeItem('cart');
                window.location.href = "index.html";
            }
        });
    } 
    // Fallback para navegadores sin SweetAlert
    else {
        const modal = document.getElementById('confirmation-modal');
        if (modal) {
            modal.style.display = 'block';
        } else {
            alert(`¡Gracias por tu compra, ${name}! Tu pedido ha sido procesado.`);
            localStorage.removeItem('cart');
            window.location.href = "index.html";
        }
    }
}