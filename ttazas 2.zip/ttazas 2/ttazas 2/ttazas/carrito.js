document.addEventListener('DOMContentLoaded', function() {
  // Elementos del DOM
  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');
  const userBtnDesktop = document.getElementById('user-btn-desktop');
  const userBtnMobile = document.getElementById('user-btn');
  const userDropdown = document.getElementById('user-dropdown');
  const userSection = document.querySelector('.user-section');
  const cartIcon = document.getElementById('cart-icon');
  const cartIconDesktop = document.getElementById('cart-icon-desktop');
  const cartModal = document.getElementById('cart-modal');
  const closeCart = document.querySelector('.close-cart');
  const keepBuyingBtn = document.getElementById('keep-buying-btn');
  const checkoutBtn = document.getElementById('checkout-btn');
  const cartItemsContainer = document.getElementById('cart-items');
  const cartTotalPrice = document.getElementById('cart-total-price');
  const cartCounters = document.querySelectorAll('.cart-counter');
  const notification = document.getElementById('notification');
  const addToCartButtons = document.querySelectorAll('.btn-anime-add');
  const registerLink = document.getElementById('register-link');
  const loginForm = document.getElementById('login-form');
  
  // Variables globales
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  // ========== FUNCIONALIDAD DEL REGISTRO ==========
  // Función para inicializar formulario de login
  function initLoginForm(container = loginForm) {
    if (!container) return;
    
    container.innerHTML = `
      <input type="text" placeholder="Usuario" required>
      <input type="password" placeholder="Contraseña" required>
      <button type="submit"><i class="fas fa-sign-in-alt"></i> Ingresar</button>
    `;
    
    container.onsubmit = function(e) {
      e.preventDefault();
      alert('¡Bienvenido otaku! (desktop)');
      if (userBtnDesktop) userBtnDesktop.innerHTML = '<i class="fas fa-user-astronaut"></i>';
      userSection.classList.remove('active');
    };
  }

  // Evento para el enlace de registro (desktop)
  if (registerLink && loginForm) {
    registerLink.addEventListener('click', function(e) {
      e.preventDefault();
      loginForm.innerHTML = `
        <input type="text" placeholder="Nombre de usuario" required>
        <input type="email" placeholder="Correo electrónico" required>
        <input type="password" placeholder="Contraseña" required>
        <input type="password" placeholder="Confirmar contraseña" required>
        <button type="submit"><i class="fas fa-user-edit"></i> Registrarse</button>
        <p class="login-switch">¿Ya tienes cuenta? <a href="#" id="login-link">Ingresar</a></p>
      `;
      
      document.getElementById('login-link').addEventListener('click', function(e) {
        e.preventDefault();
        initLoginForm();
      });
      
      loginForm.onsubmit = function(e) {
        e.preventDefault();
        alert('¡Registro exitoso! Ahora puedes iniciar sesión.');
        initLoginForm();
      };
    });
  }

  // Inicializar formulario de login al cargar
  if (loginForm) {
    initLoginForm();
  }

  // ========== FUNCIONALIDAD DEL MENÚ ==========
  if (menuToggle) {
    menuToggle.addEventListener('click', function() {
      this.classList.toggle('active');
      navMenu.classList.toggle('active');
      
      if (userSection && userSection.classList.contains('active')) {
        userSection.classList.remove('active');
      }
    });
  }
  
  // ========== FUNCIONALIDAD DEL USUARIO ==========
  if (userBtnDesktop) {
    userBtnDesktop.addEventListener('click', function(e) {
      e.stopPropagation();
      userSection.classList.toggle('active');
    });
  }
  
  if (userBtnMobile) {
    userBtnMobile.addEventListener('click', function(e) {
      e.stopPropagation();
      if (!document.getElementById('user-dropdown-mobile')) {
        const mobileDropdown = document.createElement('div');
        mobileDropdown.id = 'user-dropdown-mobile';
        mobileDropdown.className = 'user-dropdown-mobile';
        mobileDropdown.innerHTML = `
          <form id="login-form-mobile">
            <input type="text" placeholder="Usuario" required>
            <input type="password" placeholder="Contraseña" required>
            <button type="submit"><i class="fas fa-sign-in-alt"></i> Ingresar</button>
          </form>
          <div class="dropdown-links">
            <a href="#" id="register-link-mobile"><i class="fas fa-user-plus"></i> Registrarse</a>
            <a href="#"><i class="fas fa-question-circle"></i> Ayuda</a>
          </div>
        `;
        this.parentNode.appendChild(mobileDropdown);
        
        document.getElementById('register-link-mobile').addEventListener('click', (e) => {
          e.preventDefault();
          mobileDropdown.innerHTML = `
            <form id="register-form-mobile">
              <input type="text" placeholder="Nombre de usuario" required>
              <input type="email" placeholder="Correo electrónico" required>
              <input type="password" placeholder="Contraseña" required>
              <input type="password" placeholder="Confirmar contraseña" required>
              <button type="submit"><i class="fas fa-user-edit"></i> Registrarse</button>
              <p class="login-switch">¿Ya tienes cuenta? <a href="#" id="login-link-mobile">Ingresar</a></p>
            </form>
          `;
          
          document.getElementById('register-form-mobile').addEventListener('submit', (e) => {
            e.preventDefault();
            alert('¡Registro exitoso desde móvil! Ahora puedes iniciar sesión.');
            initMobileLoginForm(mobileDropdown);
          });
          
          document.getElementById('login-link-mobile').addEventListener('click', (e) => {
            e.preventDefault();
            initMobileLoginForm(mobileDropdown);
          });
        });
        
        document.getElementById('login-form-mobile').addEventListener('submit', (e) => {
          e.preventDefault();
          alert('¡Bienvenido otaku! (desde móvil)');
          userBtnMobile.innerHTML = '<i class="fas fa-user-astronaut"></i>';
          mobileDropdown.remove();
        });
      } else {
        document.getElementById('user-dropdown-mobile').remove();
      }
    });
  }
  
  function initMobileLoginForm(container) {
    container.innerHTML = `
      <form id="login-form-mobile">
        <input type="text" placeholder="Usuario" required>
        <input type="password" placeholder="Contraseña" required>
        <button type="submit"><i class="fas fa-sign-in-alt"></i> Ingresar</button>
      </form>
      <div class="dropdown-links">
        <a href="#" id="register-link-mobile"><i class="fas fa-user-plus"></i> Registrarse</a>
        <a href="#"><i class="fas fa-question-circle"></i> Ayuda</a>
      </div>
    `;
    
    document.getElementById('register-link-mobile').addEventListener('click', (e) => {
      e.preventDefault();
      container.innerHTML = `
        <form id="register-form-mobile">
          <input type="text" placeholder="Nombre de usuario" required>
          <input type="email" placeholder="Correo electrónico" required>
          <input type="password" placeholder="Contraseña" required>
          <input type="password" placeholder="Confirmar contraseña" required>
          <button type="submit"><i class="fas fa-user-edit"></i> Registrarse</button>
          <p class="login-switch">¿Ya tienes cuenta? <a href="#" id="login-link-mobile">Ingresar</a></p>
        </form>
      `;
      
      document.getElementById('register-form-mobile').addEventListener('submit', (e) => {
        e.preventDefault();
        alert('¡Registro exitoso desde móvil! Ahora puedes iniciar sesión.');
        initMobileLoginForm(container);
      });
      
      document.getElementById('login-link-mobile').addEventListener('click', (e) => {
        e.preventDefault();
        initMobileLoginForm(container);
      });
    });
    
    document.getElementById('login-form-mobile').addEventListener('submit', (e) => {
      e.preventDefault();
      alert('¡Bienvenido otaku! (desde móvil)');
      userBtnMobile.innerHTML = '<i class="fas fa-user-astronaut"></i>';
      container.remove();
    });
  }
  
  document.addEventListener('click', function(e) {
    if (userSection && !userSection.contains(e.target) && !userBtnDesktop.contains(e.target) && !userBtnMobile.contains(e.target)) {
      userSection.classList.remove('active');
    }
    
    const mobileDropdown = document.getElementById('user-dropdown-mobile');
    if (mobileDropdown && !mobileDropdown.contains(e.target) && !userBtnMobile.contains(e.target)) {
      mobileDropdown.remove();
    }
  });
  
  // ========== FUNCIONALIDAD DEL CARRITO ==========
  const openCartModal = function(e) {
    e.preventDefault();
    if (cartModal) cartModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    renderCart();
  };
  
  if (cartIcon) cartIcon.addEventListener('click', openCartModal);
  if (cartIconDesktop) cartIconDesktop.addEventListener('click', openCartModal);

  if (closeCart) {
    closeCart.addEventListener('click', function() {
      if (cartModal) cartModal.style.display = 'none';
      document.body.style.overflow = 'auto';
    });
  }

  if (keepBuyingBtn) {
    keepBuyingBtn.addEventListener('click', function() {
      if (cartModal) cartModal.style.display = 'none';
      document.body.style.overflow = 'auto';
    });
  }

  window.addEventListener('click', function(e) {
    if (e.target === cartModal) {
      cartModal.style.display = 'none';
      document.body.style.overflow = 'auto';
    }
  });

  addToCartButtons.forEach(button => {
    button.addEventListener('click', function() {
      const id = this.getAttribute('data-id');
      const name = this.getAttribute('data-name');
      const price = parseFloat(this.getAttribute('data-price'));
      const img = this.getAttribute('data-img');
      
      addToCart(id, name, price, img);
      showNotification(`${name} añadido al carrito!`);
    });
  });

  function addToCart(id, name, price, img) {
    const existingItem = cart.find(item => item.id === id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id,
        name,
        price,
        img,
        quantity: 1
      });
    }

    updateCart();
    saveCart();
  }

  function renderCart() {
    if (!cartItemsContainer) return;
    
    cartItemsContainer.innerHTML = '';

    if (cart.length === 0) {
      if (cartTotalPrice) cartTotalPrice.textContent = '$0.00';
      if (checkoutBtn) checkoutBtn.style.display = 'none';
      return;
    }

    if (checkoutBtn) checkoutBtn.style.display = 'block';

    let total = 0;
    
    cart.forEach(item => {
      const itemTotal = item.price * item.quantity;
      total += itemTotal;

      const cartItemElement = document.createElement('div');
      cartItemElement.className = 'cart-item';
      cartItemElement.innerHTML = `

        <div class="cart-item-details">
          <h3 class="cart-item-title">${item.name}</h3>
          <p class="cart-item-price">$${item.price.toFixed(2)} c/u</p>
        </div>
        <div class="cart-item-actions">
          <div class="quantity-controls">
            <button class="decrease-quantity" data-id="${item.id}">-</button>
            <span>${item.quantity}</span>
            <button class="increase-quantity" data-id="${item.id}">+</button>
          </div>
          <p class="item-total">$${itemTotal.toFixed(2)}</p>
          <button class="remove-item" data-id="${item.id}">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      `;
      cartItemsContainer.appendChild(cartItemElement);
    });

    document.querySelectorAll('.decrease-quantity').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        updateQuantity(id, -1);
      });
    });

    document.querySelectorAll('.increase-quantity').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        updateQuantity(id, 1);
      });
    });

    document.querySelectorAll('.remove-item').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        removeItem(id);
      });
    });

    if (cartTotalPrice) cartTotalPrice.textContent = `$${total.toFixed(2)}`;
  }

  function updateQuantity(id, change) {
    const itemIndex = cart.findIndex(item => item.id === id);
    
    if (itemIndex !== -1) {
      cart[itemIndex].quantity += change;
      
      if (cart[itemIndex].quantity <= 0) {
        cart.splice(itemIndex, 1);
      }
      
      updateCart();
      saveCart();
    }
  }

  function removeItem(id) {
    cart = cart.filter(item => item.id !== id);
    updateCart();
    saveCart();
  }

  function updateCart() {
    renderCart();
    updateCartCounter();
  }

  function updateCartCounter() {
    if (!cartCounters || cartCounters.length === 0) return;
    
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    cartCounters.forEach(counter => {
      counter.textContent = totalItems;
      counter.style.display = totalItems > 0 ? 'flex' : 'none';
    });
  }

  function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
  }

  function showNotification(message) {
    if (!notification) return;
    
    notification.querySelector('.notification-text').textContent = message;
    notification.classList.add('show');
    
    setTimeout(() => {
      notification.classList.remove('show');
    }, 2500);
  }

  if (checkoutBtn) {
  checkoutBtn.addEventListener('click', function() {
    if (cart.length === 0) return;
    
    // Guardar el carrito actualizado antes de redirigir
    saveCart();
    
    // Redirigir a la página de pago
    window.location.href = 'pago.html';
  });
}

  // ========== OTRAS FUNCIONALIDADES ==========
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: 'smooth'
        });
      }
      
      if (window.innerWidth <= 768) {
        if (menuToggle) menuToggle.classList.remove('active');
        if (navMenu) navMenu.classList.remove('active');
      }
    });
  });

  // Inicializar carrito
  updateCartCounter();
});

function updateOrderSummary(cartItems) {
    // Calcular subtotal sumando todos los productos
    let subtotal = 0;
    const productsContainer = document.getElementById('order-products');
    
    // Limpiar contenedor primero
    productsContainer.innerHTML = '';
    
    // Añadir cada producto y calcular subtotal
    cartItems.forEach(item => {
        const productElement = document.createElement('div');
        productElement.className = 'order-product';
        productElement.innerHTML = `
            <span>${item.name} x${item.quantity}</span>
            <span>$${(item.price * item.quantity).toFixed(2)}</span>
        `;
        productsContainer.appendChild(productElement);
        
        subtotal += item.price * item.quantity;
    });
    
    // Actualizar subtotal
    const subtotalElement = document.getElementById('summary-subtotal');
    if (subtotalElement) {
        subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
    }
    
    // Coste de envío (puedes hacerlo configurable)
    const shipping = 3.00;
    const shippingElement = document.getElementById('summary-shipping');
    if (shippingElement) {
        shippingElement.textContent = `$${shipping.toFixed(2)}`;
    }
    
    // Calcular y actualizar total
    const total = subtotal + shipping;
    const totalElement = document.getElementById('summary-total');
    if (totalElement) {
        totalElement.textContent = `$${total.toFixed(2)}`;
    }
    
    // Guardar en localStorage si es necesario
    localStorage.setItem('cartTotal', total.toFixed(2));
}





